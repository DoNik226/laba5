package fileLogic;

import java.io.IOException;
import java.util.*;


public interface BaseReader {
    LinkedHashMap<String[], String> readFromFile(String path) throws IOException;
}
