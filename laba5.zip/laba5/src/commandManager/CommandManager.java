package commandManager;

import commandManager.commands.*;
import exceptions.BuildObjectException;
import exceptions.CommandInterruptedException;
import exceptions.UnknownCommandException;
import exceptions.WrongAmountOfArgumentsException;
import models.LabWork;
import models.handlers.ModuleHandler;
import models.handlers.nonUserMode.LabWorkNonCLIHandler;
import models.handlers.userMode.LabWorkCLIHandler;

import java.util.HashMap;
import java.util.Optional;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Command Manager for interactive collection manage. For execute commands, use CommandExecutor class
 *
 * @see CommandExecutor
 * @since 1.0
 * @author Nikita
 */
public class CommandManager {

    private static final Logger myLogger = Logger.getLogger("com.github.DoNok226.laba5");
    HashMap<String, Cmd> commands;

    /**
     * Setup command manager and all of its commands.
     */
    public CommandManager()
    {
        commands = new HashMap<>();

        //commands.put("help", new HelpCmd());
        commands.put("info", new InfoCmd());
        commands.put("show", new ShowCmd());
        commands.put("add", new AddCmd());
        commands.put("update", new UpdateCmd());
        commands.put("remove_by_id", new RemoveByIdCmd());
        commands.put("clear", new ClearCmd());
        commands.put("save", new SaveCmd());
        //commands.put("execute_script", new ExecuteScriptCmd());
        commands.put("exit", new ExitCmd());
        //commands.put("add_if_max", new AddIfMaxCmd());
        //commands.put("add_if_min", new AddIfMinCmd());
        //commands.put("remove_greater", new RemoveGreaterCmd());
        //commands.put("remove_lower", new RemoveLowerCmd());
        //commands.put("print_unique_discipline", new PrintUniqueDisciplineCmd());
        //commands.put("print_field_descending_minimal_point", new PrintFieldDescendingMinimalPointCmd());
    }

    /**
     * Constructor provides choice of commands behavior: ex. userMode or nonUserMode
     *
     * @since 1.1
     * @see CommandMode
     * @param mode Mode for CommandHandler
     * @param scanner Commands scanner
     */
    public CommandManager(CommandMode mode, Scanner scanner) {
        commands = new HashMap<>();

        //commands.put("help", new HelpCmd());
        commands.put("info", new InfoCmd());
        commands.put("show", new ShowCmd());
        commands.put("remove_by_id", new RemoveByIdCmd());
        commands.put("clear", new ClearCmd());
        commands.put("save", new SaveCmd());
        //commands.put("execute_script", new ExecuteScriptCmd());
        commands.put("exit", new ExitCmd());
        //commands.put("print_field_descending_minimal_point", new PrintFieldDescendingMinimalPointCmd());
        //commands.put("print_unique_discipline", new PrintUniqueDisciplineCmd());

        ModuleHandler<LabWork> handler = null;
        switch (mode)
        {
            case CLI_UserMode -> handler = new LabWorkCLIHandler();
            case NonUserMode -> handler = new LabWorkNonCLIHandler(scanner);
        }

        commands.put("add", new AddCmd(handler));
        commands.put("update", new UpdateCmd(handler));
        //commands.put("add_if_max", new AddIfMaxCmd(handler));
        //commands.put("add_if_min", new AddIfMinCmd(handler));
        //commands.put("remove_lower", new RemoveLowerCmd(handler));
        //commands.put("remove_greater", new RemoveGreaterCmd(handler));
    }

    /**
     * Get all commands from manager.
     *
     * @return Map of loaded commands
     */
    public HashMap<String, Cmd> getCommands() {
        return commands;
    }

    /**
     * Universe method for command executing.
     *
     * @param args full separated line from stream
     */
    public void executeCommand(String[] args) {
        try {
            Optional.ofNullable(commands.get(args[0])).orElseThrow(() -> new UnknownCommandException("Указанная команда не была обнаружена")).execute(args);
        } catch (IllegalArgumentException | NullPointerException e) {
            myLogger.log(Level.SEVERE, "Выполнение команды пропущено из-за неправильных предоставленных аргументов! (" + e.getMessage() + ")");
            throw new CommandInterruptedException(e);
        } catch (BuildObjectException | UnknownCommandException e) {
            myLogger.log(Level.SEVERE, e.getMessage());
            throw new CommandInterruptedException(e);
        } catch (WrongAmountOfArgumentsException e) {
            myLogger.log(Level.SEVERE, "Wrong amount of arguments! " + e.getMessage());
            throw new CommandInterruptedException(e);
        } catch (Exception e) {
            myLogger.log(Level.SEVERE, "В командном менеджере произошла непредвиденная ошибка! " + e.getMessage());
            throw new CommandInterruptedException(e);
        }
    }
}