package models;

public enum Difficulty  {
    NORMAL,
    INSANE,
    TERRIBLE;
}