package models.validators;
/**
 * Implementation of validator for minimalPoint field. (LabWork)
 *
 * @since 1.0
 * @author Nikita
 */
public class MinimalPointValidator implements Validator<Integer> {
    /**
     * Checks if value not null and value > 0.
     *
     * @see models.LabWork
     * @param value minimalPoint to validate
     * @return true/false -- matches the restrictions
     */
    @Override
    public boolean validate(Integer value) {
        if (value == null) return false;
        return (value > 0);
    }
}