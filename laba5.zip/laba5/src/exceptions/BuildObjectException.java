package exceptions;

public class BuildObjectException extends Exception{
    public BuildObjectException(String msg)
    {
        super(msg);
    }
}
