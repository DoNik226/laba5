package exceptions;

public class StreamInterruptedException extends Exception{
    public StreamInterruptedException(String msg)
    {
        super(msg);
    }
}
